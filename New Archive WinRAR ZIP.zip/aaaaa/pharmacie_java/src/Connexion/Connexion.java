
package Connexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mimoo
 */
public class Connexion {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    
    private String url="jdbc:mysql://localhost:3306/pharmacie";
    private String login ="root";
    private String password ="";
    private static Connexion unique;
    private Connection connection;
    
  private Connexion() throws ClassNotFoundException{
  
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, login, password);
        } catch (SQLException ex) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
        }
  }

     // un objet de la classe Connexion
    public static Connexion getInstance() throws SQLException, ClassNotFoundException
    { 
        if(unique == null)
        {
            unique = new Connexion();
        }
        return unique;
    }
    
    public Connection getConnection() {
        return connection;
    }
    
     public static boolean execUpdate(String req) throws ClassNotFoundException
    {
        try {
            int res = 0;
            
            Statement state = Connexion.getInstance().connection.createStatement();
            res = state.executeUpdate(req);
            if(res == 0)
                return false;
            
        } catch (SQLException ex) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }
                
}
