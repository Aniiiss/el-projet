package Service;

import Connexion.Connexion;
import Entites.Vente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class VenteServices {
    
        //ajout f vente
    public boolean Add(Vente v) throws SQLException, Exception {
        String r = "INSERT INTO vente(`Date of Command`,Client,`Prix Article`, Qte,Total,`Command Number`) VALUES('" + v.getDate() + "','" + v.getClient() + "','" + v.getPrix() + "','" + v.getQte() + "','" + v.getTotal() + "','" + v.getCommand() + "')";
        return (Connexion.getInstance().execUpdate(r));
    }

    public List ListeVente() throws SQLException, Exception {
        Vente V = new Vente();
        List L = new ArrayList();
        String r = "SELECT * FROM vente";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet rst = state.executeQuery(r);
        while (rst.next()) {
            V = new Vente(rst.getString(1),rst.getInt(2),rst.getDouble(3),rst.getInt(4),rst.getDouble(5),rst.getInt(6));
            L.add(V);
        }
        return L;
    }

    public boolean Update(Vente v) throws SQLException, Exception {
        String q = "UPDATE `vente` SET `Date of Command` ='" + V.getDate() + "'WHERE `Command Number`=" + V.getCode();

        return (Connexion.getInstance().execUpdate(q));
    }

    public boolean Delete(int code) throws SQLException, Exception {
        String r = "DELETE FROM client WHERE cin=" + code;
        return (Connexion.getInstance().execUpdate(r));
    }
     public List Find(int name)throws SQLException, Exception
     {
        Vente p =new Vente();
        List l = new ArrayList();
        String r="SELECT * FROM vente WHERE `Command`='"+name+"'";
        Statement state =Connexion.getInstance().getConnection().createStatement();
        ResultSet rst=state.executeQuery(r);
            while (rst.next())
            {
                 p=new Vente(rst.getString(1),rst.getInt(2),rst.getDouble(3),rst.getInt(4),rst.getDouble(5),rst.getInt(6));
                 l.add(p);
            }
        return l;
     }
    
}
