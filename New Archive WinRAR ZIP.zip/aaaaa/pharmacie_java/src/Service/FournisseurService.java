/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Connexion.Connexion;
import Entites.Fournisseur;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author sahar
 */
public class FournisseurService {
    public boolean Add(Fournisseur p)throws SQLException, Exception
    {
  String r ="INSERT INTO fournisseur(name, adresse, mail, phone) VALUES ('"+p.getFullname()+"','"+p.getAdresse()+"','"+p.getMail()+"','"+p.getTlf()+"')";

  return (Connexion.getInstance().execUpdate(r));
    } 
    
    public boolean Delete(String name)throws SQLException, Exception
    {
        String r ="DELETE FROM `fournisseur` WHERE `name` LIKE '%"+name+"%'";
        return (Connexion.getInstance().execUpdate(r));
    }
     public List ListeFournisseur()throws SQLException, Exception
     {
         Fournisseur p =new Fournisseur();
         List l = new ArrayList();
         String r="SELECT * FROM `fournisseur`";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new Fournisseur(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getInt(5));
                 l.add(p);
             }
         return l;
     }
       public List Find(String name)throws SQLException, Exception
     {
         Fournisseur p =new Fournisseur();
         List l = new ArrayList();
            String r="SELECT * FROM `fournisseur` WHERE name LIKE '%"+name+"%'";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new Fournisseur(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getInt(5));
                 l.add(p);
             }
         return l;
     }
        public boolean Update(Fournisseur p)throws SQLException, Exception
    {
                String q ="UPDATE `fournisseur` SET `name` ='"+p.getFullname()+"',`adresse` ='"+p.getAdresse()+"',`mail` ='"+p.getMail()+"',`phone` ='"+p.getTlf()+"'WHERE `id`="+p.getId();


        return (Connexion.getInstance().execUpdate(q));
    }
          public DefaultComboBoxModel listerNameSupp() throws SQLException, ClassNotFoundException {
        DefaultComboBoxModel cat = new DefaultComboBoxModel();

        String req = "SELECT `name` FROM `fournisseur` ";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet res = state.executeQuery(req);

        while (res.next()) {
            String Cat = res.getString(1);
            cat.addElement(Cat);
        }
        return cat;

    }
}
