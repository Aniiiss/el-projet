/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Connexion.Connexion;
import Entites.Categorie;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author sahar
 */
public class CategorieService {

    public List listerCat() throws SQLException, ClassNotFoundException {
        Categorie Cat = new Categorie();
        List ls = new ArrayList();

        String req = "SELECT `id`,`Name` FROM `categorie` ";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet res = state.executeQuery(req);

        while (res.next()) {
            Cat = new Categorie(res.getInt(1), res.getString(2));
            ls.add(Cat);
        }
        return ls;

    }

    public DefaultComboBoxModel listerNameCat() throws SQLException, ClassNotFoundException {
        DefaultComboBoxModel cat = new DefaultComboBoxModel();

        String req = "SELECT `Name` FROM `categorie` ";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet res = state.executeQuery(req);

        while (res.next()) {
            String Cat = res.getString(1);
            cat.addElement(Cat);
        }
        return cat;

    }

    public List Find(String name) throws SQLException, Exception {
        Categorie C = new Categorie();
        List ls = new ArrayList();
        String req = "SELECT `id`,`Name`"
                + "FROM `categorie` WHERE `Name` LIKE '%" + name + "%'";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet res = state.executeQuery(req);
        while (res.next()) {
            C = new Categorie(res.getInt(1), res.getString(2));
            ls.add(C);
        }
        return ls;
    }

    public boolean Add(Categorie C) throws SQLException, Exception {

        String requete = "INSERT INTO categorie( Name) VALUES  ('" + C.getName() + "')";

        return (Connexion.getInstance().execUpdate(requete));
    }

    public boolean Update(Categorie c) throws SQLException, Exception {

        String requete = "UPDATE categorie SET `Name`='" + c.getName()+ "' WHERE `id` = " + c.getId();

        return (Connexion.getInstance().execUpdate(requete));
    }

    public boolean Delete(int id) throws SQLException, Exception {
        String requete = "DELETE FROM categorie WHERE ID =" + id;
        return (Connexion.getInstance().execUpdate(requete));
    }

}
