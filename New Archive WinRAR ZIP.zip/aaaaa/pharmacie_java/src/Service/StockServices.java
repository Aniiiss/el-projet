package Service;

import Connexion.Connexion;
import Entites.Stock;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StockServices {
    
    //ajout f stock
    public boolean Add (Stock s)throws SQLException,Exception{
        String r ="INSERT INTO stock(`Nom Article`, `Code Article`, `Qte Entree`, `Qte Sortie`, Reste) VALUES('"+s.getNom()+"','" + s.getCode()+"','" + s.getQteE() +"','" +  s.getQteS() +"','" +  s.getReste() +"' )";
        return (Connexion.getInstance().execUpdate(r)); 
    }
    
    public List ListStock() throws SQLException,Exception{
        Stock S = new Stock();
        List L = new ArrayList();
        String r="SELECT * FROM stock";
        Statement state=Connexion.getInstance().getConnection().createStatement();
        ResultSet rst = state.executeQuery(r);
        while(rst.next()){
            S = new Stock(rst.getString(1),rst.getInt(2),rst.getInt(3),rst.getInt(4),rst.getInt(5));
            L.add(S);   
        }
        return L;
    } 
    
    public boolean Update (Stock s)throws SQLException,Exception{
        String r ="UPDATE `stock` SET ("`Nom Article` ='" + s.getNom() + "',`Qte Entree` ='" + s.getQteE() +"',`Qte Sortie` ='" + s.getQteS() +"',`Reste` ='" + s.getReste() +"'WHERE `Code`=" + s.getCode()");
        return (Connexion.getInstance().execUpdate(r)); 
    }
    
    public boolean Delete(int code) throws SQLException, Exception {
        String r = "DELETE FROM stock WHERE Code=" + Code;
        return (Connexion.getInstance().execUpdate(r));
    }
     public List Find(int name)throws SQLException, Exception
     {
        Stock p =new Stock();
        List l = new ArrayList();
        String r="SELECT * FROM Stock WHERE `Code`='"+name+"'";
        Statement state =Connexion.getInstance().getConnection().createStatement();
        ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new Stock(rst.getString(1),rst.getInt(2),rst.getInt(3),rst.getInt(4),rst.getInt(5));
                 l.add(p);
             }
         return l;
     }

    
    
    
//    public List<Stock> Find(int parseInt) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public void Delete(int parseInt) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public void Update(Stock s) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public List<Stock> ListeStock() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
