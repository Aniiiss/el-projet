/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Connexion.Connexion;
import Entites.Products;
import Entites.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sahar
 */
public class UserService {
     public boolean Add(User p)throws SQLException, Exception
    {
  String r ="INSERT INTO user( First_Name, Last_Name, Sexe, adrresse,Mail,Phone) VALUES('"+p.getPrenom()+"','"+p.getNom()+"','"+p.getSexe()+"','"+p.getAdresse()+"','"+p.getMail()+"','"+p.getTel()+"')";
  return (Connexion.getInstance().execUpdate(r));
    }
     public boolean Delete(int code)throws SQLException, Exception
    {
        String r ="DELETE FROM user WHERE id="+code;
        return (Connexion.getInstance().execUpdate(r));
    }
     public List ListeUser()throws SQLException, Exception
     {
         User p =new User();
         List l = new ArrayList();
         String r="SELECT * FROM `user`";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new User(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6),rst.getString(7));
                 l.add(p);
             }
         return l;
     }
      public List Find(String name)throws SQLException, Exception
     {
         User p =new User();
         List l = new ArrayList();
 String r="SELECT * FROM user WHERE `First_Name` LIKE '%"+name+"%'";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new User(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6),rst.getString(7));
                 l.add(p);
             }
         return l;
     }
          public boolean Update(User p)throws SQLException, Exception
    {
        String r ="UPDATE `user` SET `adrresse` ='"+p.getAdresse()+"',`Phone` ='"+p.getTel()+"',`Mail` ='"+p.getMail()+"'WHERE `id`="+p.getId();
        
        return (Connexion.getInstance().execUpdate(r));
    }
}
