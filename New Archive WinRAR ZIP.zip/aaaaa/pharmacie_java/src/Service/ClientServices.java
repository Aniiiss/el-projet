package Service;

import Connexion.Connexion;
import Entites.Client;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ClientServices {

    //NABDAW AJOUT TE3 NV CLIENT
    public boolean Add(Client c) throws SQLException, Exception {
        String r = "INSERT INTO client( cin, fullname, sexe, Adresse,`Phone Number`) VALUES('" + c.getCin() + "','" + c.getFullname() + "','" + c.getSexe() + "','" + c.getAdresse() + "','" + c.getPhone() + "')";
        return (Connexion.getInstance().execUpdate(r));
    }

    public List ListeClient() throws SQLException, Exception {
        Client C = new Client();
        List L = new ArrayList();
        String r = "SELECT * FROM client";
        Statement state = Connexion.getInstance().getConnection().createStatement();
        ResultSet rst = state.executeQuery(r);
        while (rst.next()) {
            C = new Client(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5));
            L.add(C);
        }
        return L;
    }

    public boolean Update(Client c) throws SQLException, Exception {
        String q = "UPDATE `client` SET `Adresse` ='" + c.getAdresse() + "',`Phone Number` ='" + c.getPhone() + "'WHERE `cin`=" + c.getCin();

        return (Connexion.getInstance().execUpdate(q));
    }

    public boolean Delete(int code) throws SQLException, Exception {
        String r = "DELETE FROM client WHERE cin=" + code;
        return (Connexion.getInstance().execUpdate(r));
    }
     public List Find(int name)throws SQLException, Exception
     {
         Client p =new Client();
         List l = new ArrayList();
 String r="SELECT * FROM client WHERE `cin`='"+name+"'";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {
                 p=new Client(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getInt(5));
                 l.add(p);
             }
         return l;
     }
}
