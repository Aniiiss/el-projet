
package Service;

import Connexion.Connexion;
import Entites.Categorie;
import Entites.Products;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProduitService {
    public boolean Add(Products p)throws SQLException, Exception
    {
        String r ="INSERT INTO produit(code, nom, prix,categorieId,nomfor) VALUES('"+p.getCode()+"','"+p.getNom()+"','"+p.getPrix()+"','"+p.getCat()+"','"+p.getNomf()+"')";
        return (Connexion.getInstance().execUpdate(r));
    }
    public boolean Update(Products p)throws SQLException, Exception
    {
        String r ="UPDATE `produit` SET `prix` ='"+p.getPrix()+"'WHERE `code`="+p.getCode();
        return (Connexion.getInstance().execUpdate(r));
    }
     public boolean Delete(int code)throws SQLException, Exception
    {
        String r ="DELETE FROM produit WHERE code="+code;
        return (Connexion.getInstance().execUpdate(r));
    }
     public List ListeProduct()throws SQLException, Exception
     {
         Products p =new Products();

         List l = new ArrayList();
         String r="SELECT * FROM `produit`";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {

                 p=new Products(rst.getString(4),rst.getInt(1),rst.getString(2),rst.getDouble(3),rst.getString(5));
                 l.add(p);
             }
         return l;
     }
     public List Find(String name)throws SQLException, Exception
     {
         Products p =new Products();
         List l = new ArrayList();

         String r="SELECT * FROM produit WHERE `nom` LIKE '%"+name+"%'";
         Statement state =Connexion.getInstance().getConnection().createStatement();
         ResultSet rst=state.executeQuery(r);
             while (rst.next())
             {

                 p=new Products(rst.getString(4),rst.getInt(1),rst.getString(2),rst.getDouble(3),rst.getString(5));
                 l.add(p);
             }
         return l;
     }
     
}
