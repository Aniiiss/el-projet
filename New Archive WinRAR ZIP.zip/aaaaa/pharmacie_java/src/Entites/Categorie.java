/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entites;
import java.util.List;


/**
 *
 * @author sahar
 */
public class Categorie {
     private int id;
    private String Name;

    public Categorie() {
    }

    public Categorie(int id, String Name) {
        this.id = id;
        this.Name = Name;
    }

    public Categorie(String Name) {
        this.Name = Name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return Name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    

}
