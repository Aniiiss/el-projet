/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entites;

/**
 *
 * @author sahar
 */
public class User {
    private int id;
    private String nom,prenom,sexe,adresse,mail,tel;

    public User( String prenom,String nom, String sexe, String adresse, String mail, String tel) {
         this.prenom = prenom;
        this.nom = nom;
        this.sexe = sexe;
        this.adresse = adresse;
        this.mail = mail;
        this.tel = tel;
    }

    public User(int id, String nom, String prenom, String sexe, String adresse, String tel) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.sexe = sexe;
        this.adresse = adresse;
        this.tel = tel;
    }
    public User(){
    }
    public User(int id,String n ,String p ,String s ,String a ,String m ,String t){
        this.id =id;
        nom=n ;
        prenom=p;
        sexe=s;
        adresse=a;
        mail=m;
        tel=t;
    }

    public int getId(){ return id;}
        public String getNom(){ return nom;}
    public String getPrenom(){ return prenom;}
    public String getSexe(){ return sexe;}
    public String getAdresse(){ return adresse;}
    public String getMail(){ return mail;}
    public String getTel(){ return tel;}
    public void setId(int i){id=i; }
    public void setNom(String i){nom=i; }
    public void setPrenom(String i){prenom=i; }
    public void setSexe(String i){sexe=i; }
    public void setMail(String i){mail=i; }
    public void setTel(String i){tel=i; }


}
