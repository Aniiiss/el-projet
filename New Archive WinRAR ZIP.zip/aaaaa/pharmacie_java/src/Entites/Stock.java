
package Entites;

public class Stock {
    private String Nom;
    private int Code,QteE,QteS,Reste;

    public Stock() {
    }

    public Stock(String Nom, int Code, int QteE, int QteS, int Reste) {
        this.Nom = Nom;
        this.Code = Code;
        this.QteE = QteE;
        this.QteS = QteS;
        this.Reste = Reste;
    }

    public String getNom() {
        return Nom;
    }
    public int getCode() {
        return Code;
    }
    public int getQteE() {
        return QteE;
    }
    public int getQteS() {
        return QteS;
    }
    public int getReste() {
        return Reste;
    }
    
    public void setNom(String Nom) {
        this.Nom = Nom;
    }
    public void setCode(int Code) {
        this.Code = Code;
    }
    public void setQteE(int QteE) {
        this.QteE = QteE;
    }
    public void setQteS(int QteS) {
        this.QteS = QteS;
    }
    public void setReste(int Reste) {
        this.Reste = Reste;
    }

    public Object QteE() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
