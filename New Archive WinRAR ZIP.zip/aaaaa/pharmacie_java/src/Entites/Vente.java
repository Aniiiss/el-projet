
package Entites;

public class Vente {
    private String Date;
    private int Client;
    private double prix;
    private int Qte;
    private double Total;
    private int Command;

    public Vente() {
    }

    public Vente(String Date, int Client, double prix, int Qte, double Total, int Command) {
        this.Date = Date;
        this.Client = Client;
        this.prix = prix;
        this.Qte = Qte;
        this.Total = Total;
        this.Command = Command;
    }
    
    public String getDate() {
        return Date;
    }

    public int getClient() {
        return Client;
    }

    public double getPrix() {
        return prix;
    }

    public int getQte() {
        return Qte;
    }

    public double getTotal() {
        return Total;
    }

    public int getCommand() {
        return Command;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setClient(int Client) {
        this.Client = Client;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public void setQte(int Qte) {
        this.Qte = Qte;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    public void setCommand(int Command) {
        this.Command = Command;
    }
    
    
    
}
