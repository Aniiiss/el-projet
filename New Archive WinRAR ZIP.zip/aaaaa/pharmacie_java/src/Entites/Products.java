package Entites;

public class Products {

    private int code;
    private String nom, catName , nomf;
    private double prix;

    public Products() {
    }

    public Products(String c, int code, String n, double p, String nomf) {

        catName = c;
        this.code = code;
        nom = n;
        prix = p;
        this.nomf=nomf;

    }

    public String getNomf() {
        return nomf;
    }

    public String getCat() {
        return catName;
    }

    public int getCode() {
        return code;
    }

    public String getNom() {
        return nom;
    }

    public double getPrix() {
        return prix;
    }

    public void setCat(String c) {
        catName = c;
    }

    public void SetCode(int c) {
        code = c;
    }

    public void SetNom(String c) {
        nom = c;
    }

    public void SetPrix(double p) {
        prix = p;
    }

}
