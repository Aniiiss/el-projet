
package Entites;

public class Fournisseur {
        private int id;

   

    public Fournisseur(int id, String fullname, String adresse, String mail, int tlf) {
        this.id = id;
        this.fullname = fullname;
        this.adresse = adresse;
        this.mail = mail;
        this.tlf = tlf;
    }

    private String fullname ,  adresse, mail;
    private int tlf;
    public Fournisseur() {
    }

    public Fournisseur(String fullname, String adresse, String soc, int tlf) {
        this.fullname = fullname;
        this.tlf = tlf;
        this.adresse = adresse;
        this.mail = soc;
    }
 public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
    public String getFullname() {
        return fullname;
    }

    public int getTlf() {
        return tlf;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getMail() {
        return mail;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setTlf(int tlf) {
        this.tlf = tlf;
    }


    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setMail(String soc) {
        this.mail = soc;
    }
    
}
