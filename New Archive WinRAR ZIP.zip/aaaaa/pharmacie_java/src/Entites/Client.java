
package Entites;

public class Client {
  private int cin,Phone;
  private String fullname, sexe, Adresse;

    public Client() {
    }

    public Client(int cin, String fullname, String sexe, String Adresse, int Phone) {
        this.cin = cin;
        this.fullname = fullname;
        this.sexe = sexe;
        this.Adresse = Adresse;
        this.Phone = Phone;
    }

    public Client(int cin, int Phone, String Adresse) {
        this.cin = cin;
        this.Phone = Phone;
        this.Adresse = Adresse;
    }

    public int getCin() {
        return cin;
    }

    public String getFullname() {
        return fullname;
    }

    public String getSexe() {
        return sexe;
    }

    public String getAdresse() {
        return Adresse;
    }

    public int getPhone() {
        return Phone;
    }

    public void setCin(int cin) {
        this.cin = cin;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public void setAdresse(String Adresse) {
        this.Adresse = Adresse;
    }

    public void setPhone(int Phone) {
        this.Phone = Phone;
    }
  
}
